CRemoteLoader (2012)
=================

My module injector for x86 (Capable of loading modules with both standard LoadLibraryA and ManualMap)

Compiled with Visual Studio 2010.
